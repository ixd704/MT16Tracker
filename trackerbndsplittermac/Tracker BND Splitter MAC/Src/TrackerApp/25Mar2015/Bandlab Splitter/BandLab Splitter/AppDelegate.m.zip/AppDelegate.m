//
//  AppDelegate.m
//  BandLab Splitter
//
//  Created by Three MediaTech Co Pvt Ltd
//  Copyright (c) 2014 Three MediaTech Co Pvt Ltd. All rights reserved.
//

#import "AppDelegate.h"

@implementation AppDelegate

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification
{
    // Insert code here to initialize your application

    [_progressBar setHidden:YES];


}

-(BOOL)applicationShouldTerminateAfterLastWindowClosed:(NSApplication *)sender	{
    return YES;
}


-(void)open:(id)sender {
    NSOpenPanel *panel;
    NSArray* fileTypes = [[NSArray alloc] initWithObjects:@"wav", @"WAV", @"bnd", @"BND", @"trk",nil];
// Use libsndfile utilities
//    NSString *deinterleave = @"/Volumes/BandlabSplitter/bin/sndfile-deinterleave";
//    NSString *rename = @"/Volumes/BandlabSplitter/bin/rename-bnd.sh";

    NSAlert *alert = [[NSAlert alloc] init];
    [alert addButtonWithTitle:@"OK"]	;
    [alert setMessageText:@"File Splitting Complete"];
    [alert setAlertStyle:NSWarningAlertStyle];

    
    NSAlert *alertinfo = [[NSAlert alloc] init];
    [alertinfo addButtonWithTitle:@"OK"]	;
    [alertinfo setMessageText:@" No Info File In Current Directory !!!!"];
    [alertinfo setAlertStyle:NSWarningAlertStyle];



    [_progressBar setIndeterminate:YES];
    [_progressBar setStyle:0];
    [_progressBar startAnimation:sender];
    [_progressBar setHidden:YES];
    [_progressView setHidden:YES];
    [_progressView addSubview:_progressBar];


    panel = [NSOpenPanel openPanel];
    [panel setFloatingPanel:YES];
    [panel setCanChooseDirectories:NO];
    [panel setCanChooseFiles:YES];
    [panel setAllowsMultipleSelection:NO];   // Limited to 1 file at a time here
    [panel setAllowedFileTypes:fileTypes];


    [panel beginWithCompletionHandler:^(NSInteger result){
        if (result == NSFileHandlingPanelOKButton) {

            // Multiple files case
            // NSInteger count = [[panel URLs] count];
            
            // Go through all input files - replace objectAtIndex:0 with objectAtIndex:count
            //for (int i=0; i<count; i++) {
        //NSArray *args1 = [NSArray arrayWithObjects:[[panel URLs] objectAtIndex:0], nil];

            NSArray *args1 = [NSArray arrayWithObjects:[[panel URL] path], nil];
         // [[NSTask launchedTaskWithLaunchPath:deinterleave arguments:args1] waitUntilExit];
             NSArray* outputfile = [[NSArray alloc] initWithArray:args1];
            
            /* Code fror reading the info file and doing the resampling for 96k Case only*/
            
            // copy the trk file name to the string
            NSString *infofilepath = [[args1 valueForKey:@"description"] componentsJoinedByString:@""];
            
            NSString *OutfileName = [[args1 valueForKey:@"description"] componentsJoinedByString:@""];
            
            NSString *file_extension = @".trk";
            NSRange result2 = [infofilepath rangeOfString:file_extension];

            
            // change the extension to .info.
            infofilepath = [infofilepath stringByReplacingOccurrencesOfString:@".bnd" withString:@".info"];
            infofilepath = [infofilepath stringByReplacingOccurrencesOfString:@".trk" withString:@".info"];
            
            // check if info file exists
            
            NSFileManager *fileManager = [NSFileManager defaultManager];
            
            if ([fileManager fileExistsAtPath:infofilepath]){
                
            }else{
                
                if ([alertinfo runModal] == NSAlertFirstButtonReturn)
                {
                    return ;
                    
                };
                
            }
            
            
            
            // read the content of file for sampling rate 96K
            NSString *myText = [NSString stringWithContentsOfFile:infofilepath];
            
            // search for rate=96000 in info file
           NSString *rate = @"rate=96000";
            NSRange result = [myText rangeOfString:rate];
           
            [_progressBar setHidden:NO];
            [_progressView setHidden:NO];
            
            
            // -rangeOfString returns the location of the string NSRange.location or NSNotFound.
            if (result.location != NSNotFound && (result2.length != 0)) {

                NSString *chnl_str = @"channels=";
                
                // Search the file contents for the given string, put the results into an NSRange structure
                //NSRange result = [myText rangeOfString:rate];
                NSRange result1 = [myText rangeOfString:chnl_str];
                
                NSUInteger indexOfChnl = result1.location +result1.length;
                
                
                NSString *chnl_cnt = [myText substringWithRange:NSMakeRange(indexOfChnl, 2)];
                chnl_cnt = [[chnl_cnt componentsSeparatedByCharactersInSet:[NSCharacterSet newlineCharacterSet]] componentsJoinedByString:@""];
               // rate=96000 found.
               // call the sox utility for resmpling the file
                
               
                    // Prepare the input argumet
                    NSString* soxinputarg = @"-t raw -r 88200 -L -e signed-integer -b 24 -c ";

                    soxinputarg = [soxinputarg stringByAppendingString:chnl_cnt];
                    //soxinputarg = [soxinputarg stringByAppendingString:@" "];
                    
                  //  NSString* InfileName = [infofilepath stringByReplacingOccurrencesOfString:@".info" withString:@".trk"];
                
                                        //NSString* Quote = @"\"";
                
                    //InfileName = [Quote stringByAppendingString:InfileName];
                    //InfileName = [InfileName stringByAppendingString:Quote];
                
                    //soxinputarg = [soxinputarg stringByAppendingString:InfileName];

                    // Sample Format : sox execution
                    // ./sox  -t raw -r 88200 -L -e signed-integer -b 24 -c 8 TAKE1.trk  -r 96000 -t wav -L -e signed-integer -b 24 -c 8 Take1.wav
                
                    // -t raw -r 88200 -L -e signed-integer -b 24 -c 8 /Users/tariq/Downloads/96K Test Files/TAKE7.trk -r 96000 -t wav -L -e signed-integer -b 24 -c 8 /Users/tariq/Downloads/96K Test Files/TAKE7.wav
                
             
                
                    // Prepare the output argument
                    // Change the outfile name to .bnd
                    OutfileName = [OutfileName stringByReplacingOccurrencesOfString:@".trk" withString:@".wav"];
                
                
                    NSString* soxoutputarg = @"-r 96000 -t wav -L -e signed-integer -b 24 -c ";
                
                    soxoutputarg = [soxoutputarg stringByAppendingString:chnl_cnt];
                    //soxoutputarg = [soxoutputarg stringByAppendingString:@" "];
                
                    //OutfileName = [Quote stringByAppendingString:OutfileName];
                    //OutfileName = [OutfileName stringByAppendingString:Quote];
                
                    //soxoutputarg = [soxoutputarg stringByAppendingString:OutfileName];
                
                    //soxinputarg = [soxinputarg stringByAppendingString:soxoutputarg];
                
                    // Convert NSString to NSArray.. as the seArgument takes NSArray
                    NSArray *tmp_nsar1 = [soxinputarg componentsSeparatedByString:@" "];
                    NSArray *tmp_nsar2 = [soxoutputarg componentsSeparatedByString:@" "];
                
                    NSMutableArray* args3 = [[NSMutableArray alloc]init];
                    [args3 addObjectsFromArray:tmp_nsar1];
                    [args3 addObjectsFromArray:args1];
                
                
                   // NSMutableArray* outputfile = [[NSMutableArray alloc] initWithArray:args1];
                    NSMutableArray* newarray = [[NSMutableArray alloc] initWithArray:0];
                
                    for(NSString __strong *mystr in outputfile){
                        mystr = [mystr stringByReplacingOccurrencesOfString:@"trk"
                                                             withString:@"bnd"];
                        
                        [newarray addObject:mystr];
                       // [outputfile replaceObjectAtIndex:numObjects withObject:mystr];
                         NSLog(@"rate found in file");
                    }
                
                    [args3 addObjectsFromArray:tmp_nsar2];
                    [args3 addObjectsFromArray:newarray];
                
                
                    NSTask *SoXtask = [[NSTask alloc] init];
                
                    [SoXtask setLaunchPath:[[NSBundle mainBundle] pathForResource:@"sox" ofType:@""]];
                

                
                    //NSArray* args4 = [[NSArray alloc] initWithObjects:@"-t", @"raw", @"-r", @"88200", @"-L", @"-e", @"signed-integer", @"-b", @"24", @"-c", @"8", @"/Users/tariq/Downloads/96K Test Files/TAKE8.trk", @"-r", @"96000", @"-t", @"wav", @"-L", @"-e", @"signed-integer", @"-b", @"24", @"-c", @"8", @"/Users/tariq/Downloads/96K Test Files/TAKE8.wav",nil];
                
                    [SoXtask setArguments:args3];
                    [SoXtask launch];
                    [SoXtask waitUntilExit];
                    [SoXtask terminate];
                
                    //argv1s = [argv1s stringByReplacingOccurrencesOfString:@".trk" withString:@".wav"];
                    outputfile = [[NSArray alloc] initWithArray:newarray];
                    NSLog(@"rate found in file");
            }
            // End of code for SoX resampling
            
           
            NSTask *task1 = [[NSTask alloc] init];
            [task1 setLaunchPath:[[NSBundle mainBundle] pathForResource:@"mydeinterleave" ofType:@""]];

            [task1 setArguments:outputfile];
            [task1 launch];

           // NSTask *task = [NSTask launchedTaskWithLaunchPath:deinterleave arguments:args1];


            [task1 waitUntilExit];

            [_progressBar setHidden:YES];

            if ([alert runModal] == NSAlertFirstButtonReturn)
            {


            };
        }
    }];
}




@end
