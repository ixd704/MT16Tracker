//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Property.rc
//
#define IDS_AUDIO_PROPS_TITLE           3
#define IDS_AUDIO_ADVANCED_TITLE        4
#define IDS_ABOUT                       5
#define IDD_AUDIOENCPROPS               100
#define IDD_ADVPROPS                    102
#define IDD_ABOUT                       105
#define IDI_ICON2                       106
#define IDC_COMBO_CBR                   1004
#define IDC_CHECK_COPYRIGHT             1007
#define IDC_CHECK_ORIGINAL              1008
#define IDC_CHECK_CRC                   1009
#define IDC_CHECK_PES                   1010
#define IDC_COMBO_VBRMIN                1013
#define IDC_TITLE_TEXT                  1016
#define IDC_RADIO_CBR                   1019
#define IDC_RADIO_VBR                   1020
#define IDC_SLIDER_QUALITY              1021
#define IDC_TEXT_QUALITY                1023
#define IDC_COMBO_VBRMAX                1024
#define IDC_COMBO_SAMPLE_RATE           1025
#define IDC_COMBO_VBRq                  1026
#define IDC_RADIO_STEREO                1027
#define IDC_RADIO_JSTEREO               1028
#define IDC_RADIO_DUAL                  1029
#define IDC_RADIO_MONO                  1030
#define IDC_CHECK_ENFORCE_MIN           1031
#define IDC_CHECK_VOICE                 1032
#define IDC_CHECK_KEEP_ALL_FREQ         1033
#define IDC_CHECK_STRICT_ISO            1034
#define IDC_CHECK_DISABLE_SHORT_BLOCK   1035
#define IDC_CHECK_XING_TAG              1036
#define IDC_CHECK_FORCE_MS              1037
#define IDC_CHECK_MODE_FIXED            1038
#define IDC_RICHEDIT_LAME               1039
#define IDC_CHECK_OVERLAP               1039
#define IDC_CHECK_STOP                  1040
#define IDC_EDIT_TEXT                   1044
#define IDC_LAME_LA                     1044
#define IDC_FORCE_MONO                  1045
#define IDC_LAME_VER                    1046
#define IDC_LAME_URL                    1047
#define IDC_SET_DURATION                1048
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        107
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1049
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
