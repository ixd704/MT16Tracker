#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sndfile.h>
#include <unistd.h>
#include "common.h"

#define	BUFFER_LEN	4096
#define	MAX_CHANNELS	16


typedef struct
{	SNDFILE * infile ;
    SNDFILE * outfile [MAX_CHANNELS] ;
    
    union
    {	double	d [MAX_CHANNELS * BUFFER_LEN] ;
        int		i [MAX_CHANNELS * BUFFER_LEN] ;
    } din ;
    
    union
    {	double	d [BUFFER_LEN] ;
        int		i [BUFFER_LEN] ;
    } dout ;
    
    int channels ;
} STATE ;

static void usage_exit (void) ;

static void deinterleave_int (STATE * state) ;
static void deinterleave_double (STATE * state) ;
static int map_channels( char *infoFileName, int *trackNo, int *fileNo, int *noOfChannels);

int
main (int argc, char **argv)
{	STATE state ;
    SF_INFO sfinfo ;
    char pathname [512], ext [32], *cptr,  infoFileName[512], deleteFileName[16][512], command[520]="rm -f ";
    int ch, double_split, map_index=0, a, b, c, deleteCount = 0, noOfChannels ;
    
    // Variables For renaming/mapping tracks
    
    int track_array[20], fileNo_array[20], mapping_mode;
    
    if (argc != 2)
    {	if (argc != 1)
        puts ("\nError : need a single input file.\n") ;
        usage_exit () ;
    } ;
    
    memset (&state, 0, sizeof (state)) ;
    memset (&sfinfo, 0, sizeof (sfinfo)) ;
    
    if ((state.infile = sf_open (argv [1], SFM_READ, &sfinfo)) == NULL)
    {	printf ("\nError : Not able to open input file '%s'\n%s\n", argv [1], sf_strerror (NULL)) ;
        exit (1) ;
    } ;
    
    if (sfinfo.channels < 1)
    {	printf ("\nError : Input file '%s' only has one channel.\n", argv [1]) ;
        exit (1) ;
    } ;
    
    state.channels = sfinfo.channels ;
    sfinfo.channels = 1 ;
    
    snprintf (pathname, sizeof (pathname), "%s", argv [1]);
    
    if ((cptr = strrchr (pathname, '.')) == NULL)
        ext [0] = 0 ;
    else
    {
        int mytemp,mytemp1, mytemp2 ;
	int mytemp3, mytemp4, mytemp5;
        mytemp = strncmp(cptr, ".bnd",3);
        mytemp1 = strncmp(cptr, ".Bnd",3);
        mytemp2 = strncmp(cptr, ".BND",3);
	mytemp3 = strncmp(cptr, ".cmb",3);
        mytemp4 = strncmp(cptr, ".Cmb",3);
        mytemp5 = strncmp(cptr, ".CMB",3);
        
        if(mytemp == 0 || mytemp1 == 0 || mytemp2 == 0 || mytemp3 == 0 || mytemp4 == 0 || mytemp5 == 0 )
            strcpy(cptr, ".wav");
        
        snprintf (ext, sizeof (ext), "%s", cptr) ;
	//else if(mytemp3 == 0 || mytemp4 == 0 || mytemp5 == 0 )
          //  strcpy(cptr, ".wav");
	 //snprintf (ext, sizeof (ext), "%s", cptr) ;
        cptr [0] = 0 ;
    } ;
    
    printf ("Input file : %s\n", pathname) ;
    puts ("Output files :") ;
    
    strcpy(infoFileName, pathname);
    
    noOfChannels = 0;
    
    // get mapping info in two arrays
    mapping_mode = map_channels(infoFileName, track_array, fileNo_array, &noOfChannels);
    
    strcpy(infoFileName, pathname);
    strcat(infoFileName, "_tr");
    
    for (ch = 0 ; ch < state.channels ; ch++)
    {
        char filename [520] ;
        
        if ( mapping_mode < 0 || noOfChannels <= 0)
        {
            snprintf (filename, sizeof (filename), "%s_%02d%s", pathname, ch, ext) ;
        }
        else if ( ch != fileNo_array[map_index])
        {
            snprintf (filename, sizeof (filename), "%s_%02d%s", pathname, ch, ext) ;
            strcpy(deleteFileName[deleteCount], filename);
            deleteCount++;
        }
        else
        {
            if (mapping_mode == 2)
            {
                a = track_array[map_index]/2;
                b = track_array[map_index] %2;
                c = a+b;
                snprintf (filename, sizeof (filename), "%s%d%s%s", infoFileName, c,(b==0 ?"R":"L"), ext) ;
                map_index++;
            }
            else
            {
                snprintf (filename, sizeof (filename), "%s%d%s", infoFileName, track_array[map_index++], ext) ;
            }
        }
        
        if ((state.outfile [ch] = sf_open (filename, SFM_WRITE, &sfinfo)) == NULL)
        {
            printf ("Not able to open output file '%s'\n%s\n", filename, sf_strerror (NULL)) ;
            exit (1) ;
        }
        
        printf ("    %s\n", filename) ;
    }
    
    switch (sfinfo.format & SF_FORMAT_SUBMASK)
    {	case SF_FORMAT_FLOAT :
        case SF_FORMAT_DOUBLE :
        case SF_FORMAT_VORBIS :
            double_split = 1 ;
            break ;
            
        default :
            double_split = 0 ;
            break ;
    } ;
    
    if (double_split)
        deinterleave_double (&state) ;
    else
        deinterleave_int (&state) ;
    
    sf_close (state.infile) ;
    for (ch = 0 ; ch < MAX_CHANNELS ; ch++)
        if (state.outfile [ch] != NULL)
            sf_close (state.outfile [ch]) ;
    
    
    if ( mapping_mode > 0 )
    {
        for (ch=0; ch < deleteCount; ch++)
            unlink (deleteFileName[ch]);
    }
    
    return 0 ;
} /* main */

/*------------------------------------------------------------------------------
 */

static void
usage_exit (void)
{	puts ("\nUsage : sndfile-deinterleave <filename>\n") ;
    puts (
          "Split a mutli-channel file into a set of mono files.\n"
          "\n"
          "If the input file is named 'a.wav', the output files will be named\n"
          "a_00.wav, a_01.wav and so on.\n"
          ) ;
    printf ("Using %s.\n\n", sf_version_string ()) ;
    exit (0) ;
} /* usage_exit */

static void
deinterleave_int (STATE * state)
{	int read_len ;
    int ch, k ;
    
    do
    {	read_len = sf_readf_int (state->infile, state->din.i, BUFFER_LEN) ;
        
        for (ch = 0 ; ch < state->channels ; ch ++)
        {	for (k = 0 ; k < read_len ; k++)
            state->dout.i [k] = state->din.i [k * state->channels + ch] ;
            sf_write_int (state->outfile [ch], state->dout.i, read_len) ;
        } ;
    }
    while (read_len > 0) ;
    
} /* deinterleave_int */

static void
deinterleave_double (STATE * state)
{	int read_len ;
    int ch, k ;
    
    do
    {	read_len = sf_readf_double (state->infile, state->din.d, BUFFER_LEN) ;
        
        for (ch = 0 ; ch < state->channels ; ch ++)
        {	for (k = 0 ; k < read_len ; k++)
            state->dout.d [k] = state->din.d [k * state->channels + ch] ;
            sf_write_double (state->outfile [ch], state->dout.d, read_len) ;
        } ;
    }
    while (read_len > 0) ;
    
} /* deinterleave_double */


static int map_channels( char *infoFileName, int *trackNo_orig, int *fileNo_orig, int *totalChannels)
{
    
    FILE *fp;
    char buf[25][50], *tok, *ret, channelNo[10];
    int i, j, a, noOfChannels,mapping_mode,  *trackNo, *fileNo;
    
   mapping_mode = -1;
	
    strcat(infoFileName,".info");
    fp = fopen(infoFileName, "rt");
    
    if(fp == NULL)
    {
        printf(" Could not open .info file \n ");
        *totalChannels = noOfChannels;
        return -1;
    }
    else
    {
        printf(" File Opened !!!  \n");
    }
    
    //   printf( "\n");
    
    // Pointer and Variables initializations
    trackNo = trackNo_orig;
    fileNo =  fileNo_orig;
    i = 0;
    j = 0;
    noOfChannels = 0;

    // Used to find the line numbers of strings "mapping_mode" and "ch_map_"
     int lineNumberForMappingMode = 0, lineNumberForChannelMap = 0;
     char tokenForMappingMode[15] = "mapping_mode";
     char tokenForChannelMap[10] = "ch_map_";

     while(!feof(fp))
     {
         if ( fgets(buf[i], 100, fp) == NULL )
             break;

        // Using an if statement to find the string "mapping_mode"
         if ( strncmp(buf[i] ,tokenForMappingMode, 12) == 0)
                 break;
             else
                 lineNumberForMappingMode++;
     }

     rewind(fp);  // reset file position indicator to start of the file.

     while(!feof(fp))
     {
         if ( fgets(buf[i], 100, fp) == NULL )
             break;

        // Using an if statement to find the string "ch_map_"
         if ( strncmp(buf[i] ,tokenForChannelMap, 7) == 0)
                 break;
             else
                 lineNumberForChannelMap++;
     }

    rewind(fp);  // reset file position indicator to start of the file.

    
    // Parsing the file till EOF is encountered
    while(!feof(fp)) {
        
        // read the entire line
        
        
        // if no bytes read, then exit the while loop
        if ( fgets(buf[i], 256, fp) == NULL )
            break;
        
        if ( i == lineNumberForMappingMode)
        {
            ret = strrchr(buf[i], '=');
            ret++;
            strcpy(channelNo, ret);
            tok = strtok(channelNo, "=");
            mapping_mode = atoi(tok);
        }
        if(i >= lineNumberForChannelMap)
        {
            // extracting track no from left of '=' sign
            ret = strrchr(buf[i], '_');
            ret++;
            strcpy(channelNo, ret);
            tok = strtok(channelNo, "=");
            *trackNo++ = atoi(tok);
            
            // extracting file no from right of '=' sign
            ret = strrchr(buf[i], '=');
            ret++;
            strcpy(channelNo, ret);
            tok = strtok(channelNo, "=");
            *fileNo++ = atoi(tok);
            
            noOfChannels++;
            
        }
        i++;
    } /*End while not EOF*/
    
    fclose(fp);
    
    trackNo = trackNo_orig;
    fileNo =  fileNo_orig;
    
    for (i = 0; i < noOfChannels; ++i)
    {
        for (j = i + 1; j < noOfChannels; ++j)
        {
            if (fileNo[i] > fileNo[j])
            {
                a =  fileNo[i];
                fileNo[i] = fileNo[j];
                fileNo[j] = a;
                
                a =  trackNo[i];
                trackNo[i] = trackNo[j];
                trackNo[j] = a;
            }
        }
    }
    
    
    fileNo =  fileNo_orig;
    
    for (i = 0; i < noOfChannels; ++i)
        fileNo[i] = fileNo[i]-1;
    
    *totalChannels = noOfChannels;
    
    return mapping_mode;
}

